#!/bin/bash
<<doc
Name : Pritesh Suryawanshi
Date: 1/9/2024
Description: Command Line Test Project
Sample input: ./a.out
Sample output:
doc
:
#!/bin/bash

sign_up ()

{
    header  # header part linked with sign_up part
    echo -e "\e[92m<<<<<\e[0m Signup \e[92m>>>>>\e[0m"
    users=(`cat user_name.csv`) # checking the content of user_name.csv file
    echo "Enter Username:"
    read username
    for user in `seq 0 $((${#users[@]}-1))`
    do
	userid=${users[$user]}
    if [ $userid = $username ] # checking the new username with the existing username
    then
	echo -e "\e[31mUsername already exists! Please use a different username.\e[0m"
	sign_up  # if username already exists then it will redirect to sign_up again
    fi
    done
    pw=1
    while [ $pw -ne 0 ]
    do
    	echo "Enter Password: "
    	read -s password
	if [ ${#password} -lt 6 ] # checking if the password length is less than 6
	then
	    echo -e "\e[31mPlease use at least 6 characters for the password.\e[0m"
	else
	    pw=0
	fi
    done
    pass=1
    attempts=4
    while [ $pass -ne 0 -a $attempts -ne 0 ]
    do
	echo "Confirm Password: "
	read -s conf_password
	if [ $conf_password = $password ] # checking if the password matches the confirmation
	then
	    pass=0
	    echo -e "\e[32mCongratulations! Your Username & Password were created successfully!\e[0m"

    	    echo $username >> user_name.csv  # storing the username inside the user_name.csv file
	    echo $conf_password >> password.csv # storing the password inside the password.csv file
	    welcome
	else
	    attempts=$(($attempts-1)) # if password doesn't match, decrease the attempt count
	    echo -e "\e[31mWrong Password! Remaining Attempts\e[0m = $attempts"

	    if [ $attempts -eq 0 ] # if attempts equal to zero then redirect to sign_up
	    then
		echo -e "\e[31mSorry! You crossed your maximum limit.\e[0m"
		echo "Signup Again!"
		sign_up
	    fi
	fi
    done

}

sign_in ()

{
    header
    echo -e "\e[32m<<<<<\e[0m Signin \e[32m>>>>>\e[0m"
    users=(`cat user_name.csv`)  # storing the contents of user_name.csv inside the 'users' variable
    found=0
    attempts=4 # 4 attempts are provided to the user
    while [ $found -ne 1 -a $attempts -ne 0 ]
    do
	echo -e "\e[34mEnter Username:\e[0m "
	read login_user
	for user in `seq 0 $((${#users[@]}-1))`
	do
	    if [ ${users[$user]} = $login_user ] # checking the username with the existing username
	    then
		found=1
		position=$user # collecting the index value of 'user' to 'position' variable
	    fi
	done
	if [ $found -eq 1 ]
	then
	    echo -e "\e[92m:) Great!\e[0m"
	else
	    echo -e "\e[31mUsername doesn't exist\e[0m"
	    attempts=$(($attempts-1)) # if condition is false, decrease the attempt count
	    if [ $attempts -gt 0 ]
	    then
		echo "Please try again"
		echo "You have $attempts attempts remaining"
	    else
		echo -e "\e[31mSorry! You crossed your maximum limit.\e[0m"
		echo "Please Signup again"
	       welcome  # after 4 attempts, redirect to the sign_up or home part
	    fi
	fi
    done

    password=(`cat password.csv`)   # storing the contents of password.csv to 'password' variable
    attempts=4
    found=0
    while [ $found -ne 1 -a $attempts -ne 0 ]
    do
	echo -e "\e[34mEnter Password:\e[0m "
	read -s login_pass
	echo
	if [ ${password[$position]} = $login_pass ]  # checking if the current password matches the existing password
	then
	    echo -e "\e[92mLogin Successful! You can start your exam.\e[0m"
	    start_test # if condition true, go to the test part
	    found=1
	else
	    echo -e "\e[31mWrong Password! Please try again.\e[0m"
	    attempts=$(($attempts-1))  # if condition false, decrease the attempt count
	    if [ $attempts -gt 0 ]
	    then
		echo "You have $attempts attempts remaining"
	    else
		echo -e "\e[31mSorry! No more attempts. Please try later\e[0m"
		welcome # if 4 attempts are over, redirect to the welcome part or home
	    fi
	fi

    done
}

start_test ()
{
    header
    echo -e "1) \e[32mTake the Test\e[0m"
    echo -e "2) \e[31mExit\e[0m"
    echo
    read -p "Enter your choice: " choice
    line=`cat question_bank.txt | wc -l`  # checking the line number of question_bank.txt file

    case $choice in
	1)
	    for i in `seq 5 5 $line` # starting i value is 5 & it will increase by 5 in each iteration
	    do
		header
		echo
		head -$i question_bank.txt | tail -5  # display the 5 lines of question_bank.txt
		echo
		for j in `seq 10 -1 1`
		do
		    echo -e "\r\e[31mEnter the correct answer\e[0m \e[32m$j\e[0m : \c" # '\r' carriage return, '\c' cursor will not move to the new line
		    read -t 1 ans # '-t' enables the time limit of 1 second, and 'ans' captures user input
		    if [ ${#ans} -ne 0 ]
		    then
			break
		    fi
		done

		if [ ${#ans} -eq 1 ]
		then
		    echo "$ans" >> user_answer.txt  # user answers are stored inside the user_answer.txt file
	        else
		    echo "No_Answer" >> user_answer.txt # if user does not provide any input, 'No_Answer' is stored by default
		fi
		echo

	    done


	;;

        2)
	    exit
	;;

    	*) echo -e "\e[31mPlease choose a correct option.\e[0m"
	   start_test
    esac
    results
}
results ()
{
    header
    c_ans=(`cat currect_answer.txt | tr -s ' ' | cut -d ':' -f1`)  # Correct answer choices
    c_ans1=(`cat currect_answer.txt | tr -s ' ' | cut -d ':' -f2`) # Correct answer explanations
    u_ans=(`tail -10 user_answer.txt`) # Fetch the last 10 answers from the user

    score=0

    for i in `seq 0 $((${#c_ans[@]}-1))`
    do
        if [ ${c_ans[i]} = ${u_ans[i]} ] # If the user's answer is correct
        then
            echo -e "Q$(($i+1))) Your answer is : \e[32m${u_ans[i]} (Correct)\e[0m"
            echo -e "Q$(($i+1))) Correct answer is : \e[32m${c_ans[i]}. ${c_ans1[i]}\e[0m\n"
            score=$(($score+1))
        else
            echo -e "Q$(($i+1))) Your answer is : \e[31m${u_ans[i]} (Incorrect)\e[0m"
            echo -e "Q$(($i+1))) Correct answer is : \e[32m${c_ans[i]}. ${c_ans1[i]}\e[0m\n"
        fi
    done
    
    echo -e "\e[32mYour Total Score\e[0m: $score Marks\n"
    exit
}

header ()

{   
    clear  # clear the display after 2 seconds
	echo ____________________________________________________
    	echo
    	echo -e "\e[32m<<<<<<<<<<<<<<<<<\e[0m \e[1;4mOnline MCQ Test\e[0m \e[32m>>>>>>>>>>>>>>>>>\e[0m"
	echo -e "\e[31mTotal Marks\e[0m : 10                    \e[31mTime\e[0m : 100 Seconds"
	echo ____________________________________________________

}
#header

welcome ()
{
    	header
    	echo -e "1.\e[92mSignup\e[0m"
	echo -e "2.\e[92mSignin\e[0m"
	echo -e "3.\e[92mExit\e[0m"
	echo

	read -p "Please choose an option : " choice

	case $choice in
   		1) echo -e "\e[92mGreat! You are ready to Signup.\e[0m"
		    sign_up
		   ;;

	        2) echo -e "\e[92mGreat! You are ready to Signin.\e[0m"
		    sign_in
		    ;;

       		3) exit
		    ;;

		*) echo -e "\e[91mPlease choose a correct option\e[0m"
		    welcome
		    ;;

	esac

}

welcome


 	
